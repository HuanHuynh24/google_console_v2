export interface KeywordGroupDto {
  query: string;
  clicks: number;
  impressions: number;
  ctr: number;
  position: number;
}
