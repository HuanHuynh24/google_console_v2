export interface PageGroupDto {
  trang: string;
  count: number;
  totalClick: number;
  ctr: number;
  avgPosition: number;
}
